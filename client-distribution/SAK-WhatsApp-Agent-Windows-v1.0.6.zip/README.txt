﻿================================================================
        SAK WhatsApp AI Desktop Agent - Setup Guide
                      Windows Edition
================================================================

Thank you for choosing SAK WhatsApp AI!

WHAT'S INCLUDED:
   * sak-whatsapp-agent-windows.exe - Main application
   * START-AGENT.bat - Easy launcher
   * RESET-SESSION.bat - Fix connection issues
   * .env - Configuration file
   * README.txt - This guide

QUICK START (5 Minutes):

STEP 1: Get Your Credentials
   1. Open your web browser
   2. Go to: http://43.205.192.171:8080
   3. Login with your credentials
   4. Go to Dashboard -> Settings -> Desktop Agent
   5. Copy your Tenant ID

STEP 2: Configure the Agent
   1. Right-click on ".env" file
   2. Select "Open with Notepad"
   3. Replace "your-tenant-id-here" with YOUR Tenant ID
   4. Enter your WhatsApp phone number (with country code)
   5. API Key is OPTIONAL - leave empty if not needed
   6. Save the file (Ctrl+S) and close Notepad

STEP 3: Start the Agent
   1. Double-click "START-AGENT.bat"
   2. A window will open with a QR code
   3. Keep this window open

STEP 4: Connect WhatsApp
   1. Open WhatsApp on your phone
   2. Tap: Menu -> Linked Devices
   3. Tap: "Link a Device"
   4. Point your phone camera at the QR code
   5. Wait for connection... Done!

YOU'RE ALL SET!
   * Your AI assistant is now live 24/7
   * It will respond to customers automatically
   * Process orders, answer questions, recommend products
   * View analytics in your web dashboard

IMPORTANT TIPS:
   * Keep the agent window open (minimize if needed)
   * Your computer must be on and connected to internet
   * The agent uses minimal resources (~50MB RAM)

SYSTEM REQUIREMENTS:
   * Windows 10 or later (64-bit)
   * Google Chrome or Microsoft Edge browser
   * Active internet connection
   * WhatsApp mobile app

TROUBLESHOOTING:

Problem: QR code doesn't appear
Solution: 
   * Run RESET-SESSION.bat first, then START-AGENT.bat
   * Check your internet connection
   * Verify Tenant ID in .env file is correct
   * Make sure you saved the .env file after editing

Problem: Agent keeps disconnecting or won't connect
Solution:
   1. Close the agent window
   2. Run RESET-SESSION.bat
   3. Run START-AGENT.bat
   4. Scan the new QR code

Problem: "Chrome not found" error
Solution:
   * Install Google Chrome: https://www.google.com/chrome/

Problem: WhatsApp won't scan QR code
Solution:
   * Ensure QR code is fully visible on screen
   * Increase screen brightness
   * Hold phone steady while scanning

Problem: Agent disconnects frequently
Solution:
   * Check your internet stability
   * Disable computer sleep mode
   * Restart the agent

NEED HELP?
   Email: support@sakwhatsapp.com
   WhatsApp: +971 50 705 5253
   Dashboard: http://43.205.192.171:8080

UPDATING THE AGENT:
   * Download the latest version from your dashboard
   * Stop the old agent (close the window)
   * Replace sak-whatsapp-agent-windows.exe with new version
   * Keep your .env file
   * Start the agent again

================================================================
SAK WhatsApp AI - 2025 | All Rights Reserved | Version $newVersion
================================================================
